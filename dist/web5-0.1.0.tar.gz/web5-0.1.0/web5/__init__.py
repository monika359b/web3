"""
An unoffical polygon deposit
"""
